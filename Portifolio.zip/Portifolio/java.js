document.addEventListener("DOMContentLoaded", function () {
  emailjs.init("YvWFau14e_RZBZYFj"); //  USER ID

  document.getElementById("contatoForm").addEventListener("submit", function (e) {
    e.preventDefault();

    const nome = document.getElementById("nome").value;
    const email = document.getElementById("email").value;
    const mensagem = document.getElementById("mensagem").value;

    // Envio do e-mail
    emailjs.send("service_l67hceo", "template_poduymg", {
      from_name: nome,
      from_email: email,
      message: mensagem
    }).then(function () {
      const confirmacao = document.getElementById("confirmacao");
      confirmacao.innerHTML = `
          Obrigado, <strong>${nome}</strong>!<br>
          Sua mensagem foi enviada com sucesso.<br>
          <strong>Email:</strong> ${email}<br>
          <strong>Mensagem:</strong> ${mensagem}
        `;
      confirmacao.classList.remove("d-none");

      // Abre WhatsApp com a mensagem
      const mensagemWhatsApp = encodeURIComponent(`Olá Guilherme, me chamo ${nome} e gostaria de conversar com você!\n\n"${mensagem}"`);
      window.open(`https://wa.me/5579998122023?text=${mensagemWhatsApp}`, '_blank');

      // Limpa formulário
      document.getElementById("contatoForm").reset();
    }, function (error) {
      alert("Erro ao enviar. Verifique o console.");
      console.error("Erro no EmailJS:", error);
    });
  });
});
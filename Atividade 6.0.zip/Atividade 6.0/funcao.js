function botao1(num){
    
    window.alert('Voce clicou no butão ' + num)

}
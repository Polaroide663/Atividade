const DISTANCIA = 120;
const VALORPED = 20.0;

let registros = [];
let inicioProcesso = null;
let finalProcesso = null;
let caixaFechado = false;

function calcularTempo(horaEntrada, horaSaida) {
  const entrada = new Date(`2023-01-01T${horaEntrada}:00`);
  const saida = new Date(`2023-01-01T${horaSaida}:00`);
  const tempoMs = saida - entrada;
  return tempoMs / 1000 / 60 / 60; 
}

function calcularDes(velocidade){
  if (velocidade <= 60) return 0.15;
  else if (velocidade <= 100) return 0.10;
  else return 0.0;
}

function controlePe() {
  if (caixaFechado) {
    alert("O caixa está fechado. Não é possível registrar novos veículos.");
    return;
  }

  const placa = document.getElementById("placa").value.trim();
  const horaEntrada = document.getElementById("horaA").value;
  const horaSaida = document.getElementById("horaB").value;

  if (!placa || !horaEntrada || !horaSaida) {
    alert("Por favor, preencha todos os campos.");
    return;
  }

  const tempo = calcularTempo(horaEntrada, horaSaida);
  const velocidade = DISTANCIA / tempo;
  const desconto = calcularDes(velocidade);
  const valorPago = VALORPED * (1 - desconto);

  if (!inicioProcesso) inicioProcesso = horaEntrada;
  finalProcesso = horaSaida;

  const registro = {
    placa,
    horaEntrada,
    horaSaida,
    tempo,
    velocidade,
    valorPago,
  };

  registros.push(registro);

  document.getElementById("registroForm").reset();
  document.getElementById("saida").textContent = `Veículo registrado com sucesso! Total de veículos registrados: ${registros.length}`;
}

function FecharCaixa() {
  if (caixaFechado) {
    alert("O caixa já está fechado.");
    return;
  }

  if (registros.length === 0) {
    alert("Nenhum registro para mostrar.");
    return;
  }

  caixaFechado = true;

  const saida = document.getElementById("saida");
  let texto = "";

  registros.forEach((r, i) => {
    texto += `\n🧾 Ticket ${i+1}\nPlaca: ${r.placa}\nEntrada: ${r.horaEntrada} - Saída: ${r.horaSaida}\nTempo: ${r.tempo.toFixed(2)} h\nVelocidade: ${r.velocidade.toFixed(2)} km/h\nValor Pago: R$ ${r.valorPago.toFixed(2)}\n\n`;
  });

  const velocidades = registros.map(r => r.velocidade);
  const menorVelocidade = Math.min(...velocidades);
  const maiorVelocidade = Math.max(...velocidades);
  const mediaVelocidade = velocidades.reduce((a, b) => a + b, 0) / velocidades.length;
  const totalValores = registros.reduce((a, b) => a + b.valorPago, 0);

  texto += `📊 RELATÓRIO FINAL\n`;
  texto += `Menor Velocidade: ${menorVelocidade.toFixed(2)} km/h\n`;
  texto += `Maior Velocidade: ${maiorVelocidade.toFixed(2)} km/h\n`;
  texto += `Velocidade Média: ${mediaVelocidade.toFixed(2)} km/h\n`;
  texto += `Total Arrecadado: R$ ${totalValores.toFixed(2)}\n`;
  texto += `Início do Turno: ${inicioProcesso}\n`;
  texto += `Fim do Turno: ${finalProcesso}\n`;

  saida.textContent = texto;

  alert("Caixa fechado com sucesso! 💰");


  document.getElementById("placa").disabled = true;
  document.getElementById("horaA").disabled = true;
  document.getElementById("horaB").disabled = true;
  document.querySelector("#registroForm button[type='submit']").disabled = true;
  document.getElementById("fecharBtn").disabled = true;
}

document.getElementById("registroForm").addEventListener("submit", function(e) {
  e.preventDefault();
  controlePe();
});

document.getElementById("fecharBtn").addEventListener("click", FecharCaixa);

function calcular() {
    const valor = document.getElementById("valor").value;
    const tempoUso = document.getElementById("tempo").value;

    const blocos = Math.ceil(tempoUso / 15);
    const total = (blocos * valor).toFixed(2);

    document.getElementById("resultado1").textContent = `${tempoUso} minutos → ${blocos} bloco(s) de 15 min | Total: R$ ${total}`;
    document.getElementById("resultado2").textContent =
        `Valor total a pagar: R$ ${total.toString().replace('.', ',')}`;

}
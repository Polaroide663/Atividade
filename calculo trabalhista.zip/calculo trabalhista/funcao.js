function mostrarsalario() {
    const valorh = parseFloat(document.getElementById('hora').value);
    const qtdh = parseFloat(document.getElementById("qtd").value);
    const dextra = parseFloat(document.getElementById("dextra").value);
    const resultadoDiv = document.getElementById("resultado");
    const transporteSelecionado = document.querySelector("input[name='Valetransporte']:checked");
    const Valetransporte = transporteSelecionado ? transporteSelecionado.value === "sim" : false;

    const valorbru = valorh * qtdh;


    let inss = 0;
    if (valorbru <= 1320) {
        inss = valorbru * 0.075;
    } else if (valorbru <= 2571.29) {
        inss = valorbru * 0.09;
    } else if (valorbru <= 3856.94) {
        inss = valorbru * 0.12;
    } else {
        inss = valorbru * 0.14;
    }

 
    const baseIr = valorbru - inss;
    let iprf = 0;
    if (baseIr > 2112 && baseIr <= 2826.65) {
        iprf = baseIr * 0.075;
    } else if (baseIr <= 3751.06) {
        iprf = baseIr * 0.15;
    } else if (baseIr <= 4664.68) {
        iprf = baseIr * 0.225;
    } else if (baseIr > 4664.68) {
        iprf = baseIr * 0.275;
    }

    const descontoVale = Valetransporte ? valorbru * 0.06 : 0;

    const salarioLiquido = valorbru - inss - iprf - descontoVale - dextra;

    resultadoDiv.innerHTML = `
        <div class="alert alert-info">
            <h4>Resultado:</h4>
            <p><strong>Salário Bruto:</strong> R$ ${valorbru.toFixed(2)}</p>
            <p><strong>INSS:</strong> R$ ${inss.toFixed(2)}</p>
            <p><strong>IRPF:</strong> R$ ${iprf.toFixed(2)}</p>
            <p><strong>Vale Transporte:</strong> R$ ${descontoVale.toFixed(2)}</p>
            <p><strong>Desconto Extra:</strong> R$ ${dextra.toFixed(2)}</p>
            <hr>
            <h5><strong>Salário Líquido:</strong> R$ ${salarioLiquido.toFixed(2)}</h5>
        </div>
    `;
}

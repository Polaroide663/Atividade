

document.getElementById("formInscricao").addEventListener("submit", function (event) {
    event.preventDefault();

    let nome = document.getElementById("nome").value;
    let email = document.getElementById("email").value;
    let nascimento = document.getElementById("nascimento").value;
    let celular = document.getElementById("celular").value;
    let telefone = document.getElementById("telefone").value;

    let conclusao = `<p><strong>Nome:</strong> ${nome}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Data de Nascimento:</strong> ${nascimento}</p>
        <p><strong>Numero de celular:</strong> ${isNaN(celular) ? "Não informado" : celular}</p>
        <p><strong>Numero de telefone:</strong> ${isNaN(telefone) ? "Não informado" : telefone}</p>`;

    document.getElementById("conclusao").innerHTML = conclusao;

    alert("Dados enviados com sucesso!");
});

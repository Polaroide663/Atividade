const display = document.getElementById("display");
const buttons = document.querySelectorAll(".buttons button");

let current = "";

buttons.forEach(button => {
  button.onclick = () => {
    const value = button.textContent;

    if (value === "AC") {
      current = "";
      display.value = "0";
    } else if (value === "=") {
      try {
        current = eval(
          current
            .replace(/÷/g, "/")
            .replace(/x/g, "*")
        ).toString();
        display.value = current;
      } catch {
        display.value = "ERRO";
        current = "";
      }
    } else {
      current += value;
      display.value = current;
    }
  };
});

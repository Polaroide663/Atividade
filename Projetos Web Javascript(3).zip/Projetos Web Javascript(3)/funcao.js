function promocao() {

    const nome = document.getElementById("produto").value;
    const preco = Number(document.getElementById("preco").value);

    const total = (2.5 * preco).toFixed(2).replace(".", ",")

    document.getElementById("resultado1").textContent = `Promoção: Leve 3 unidades de ${nome} e pague metade de 1!`;
    document.getElementById("resultado2").textContent =  `Total com desconto: R$ ${total}`;
}
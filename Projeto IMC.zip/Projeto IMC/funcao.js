function imc() {
    const nome = document.getElementById("nome").value.trim();
    const peso = parseFloat(document.getElementById("peso").value.replace(',', '.'));
    const altura = parseFloat(document.getElementById("altura").value.replace(',', '.'));
    const generoMasculino = document.getElementById("masc").checked;
    const generoFeminino = document.getElementById("fem").checked;

    const resultadoIMC = peso / (altura * altura);
    const imcFormatado = resultadoIMC.toFixed(2);

    let classificacao = "";

    if (generoMasculino) {
        if (resultadoIMC < 20.7) classificacao = "Abaixo do peso";
        else if (resultadoIMC <= 26.4) classificacao = "Peso ideal";
        else if (resultadoIMC <= 27.8) classificacao = "Um pouco acima do peso";
        else if (resultadoIMC <= 31.1) classificacao = "Acima do peso ideal";
        else classificacao = "Obeso";
    } else {
        if (resultadoIMC < 19.1) classificacao = "Abaixo do peso";
        else if (resultadoIMC <= 25.8) classificacao = "Peso ideal";
        else if (resultadoIMC <= 27.3) classificacao = "Um pouco acima do peso";
        else if (resultadoIMC <= 32.3) classificacao = "Acima do peso ideal";
        else classificacao = "Obesa";
    }

    alert(`${nome}, seu IMC é ${imcFormatado}. Classificação: ${classificacao}.`);
}

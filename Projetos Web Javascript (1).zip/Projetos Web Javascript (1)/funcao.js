function mostrarPromocao() {
    const nome = document.getElementById("medicamento").value;
    const valor = Number(document.getElementById("preco").value);

    const precoTotal = valor * 2;
    const precoProm = Math.floor(precoTotal);

    document.getElementById("resultado1").textContent = "Promoção de " + nome;
    document.getElementById("resultado2").textContent = "Leve 2 por apenas R$: " + precoProm.toFixed(2);
}